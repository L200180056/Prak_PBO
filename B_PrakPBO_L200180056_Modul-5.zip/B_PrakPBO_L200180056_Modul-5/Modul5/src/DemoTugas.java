/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Win 8.1
 */
public class DemoTugas {
    public static void main(String[] args){
        Tugas tg = new Tugas("Aprinta Sewelastami","L200180088", 2018);
        
    }
}
