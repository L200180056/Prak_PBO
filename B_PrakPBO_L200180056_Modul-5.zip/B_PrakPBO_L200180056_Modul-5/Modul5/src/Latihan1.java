/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bayu
 */
public class Latihan1 {
    String nama = "bayu prayitno a";
    String nim = "L200180054";
    String alamat = "PWDD";
    
    Latihan1(){
    System.out.println("Nama : " + nama + "\n" +
                       "NIM : " + nim + "\n" +
                       "Alamat : " + alamat + "\n");
    }
}
