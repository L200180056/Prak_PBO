
import java.util.Scanner;
public class AplikasiLampu {
    public static void main(String[] args){
        Lampu lampu = new Lampu();
        Scanner sc = new Scanner(System.in);
        lampu.statusLampu = lampu.setSaklar(0);
        System.out.println("Status Lampu = " + lampu.statusLampu +"\n Ketikkan");
        System.out.println("1 Untuk menyalakan Lampu\n0 Untuk mematikan Lampu\n2 Untuk meredupkan Lampu");
        
        if(lampu.setSaklar(sc.nextInt()) == 0){
            lampu.matikanLampu();           
        }else if(lampu.statusLampu == 1){
            lampu.hidupkanLampu();
        }else{
            lampu.redupkanLampu();
        }
    }
}
